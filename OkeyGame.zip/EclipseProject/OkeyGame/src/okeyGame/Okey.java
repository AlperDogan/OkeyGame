package okeyGame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

public class Okey {

	/**
	 * Bu program klasik okey oyununa g�re rastgele da��t�lan 4 el aras�ndan 
	 * belirlenen puanlama algoritmas�na g�re bitirmeye en yak�n eli belirlemektedir.
	 * Not: Oyuncular�n �ifte gitme durumu dikkate al�nmam��t�r.
	 */
	public static void main(String[] args) {
		 
		ArrayList<Integer> okeyStones = new ArrayList<Integer>();
		ArrayList<List<Integer>> playersStones= new ArrayList<List<Integer>>();
		List<Integer> firstPlayerStones = new ArrayList<Integer>();
		List<Integer> secondPlayerStones = new ArrayList<Integer>();
		List<Integer> thirdPlayerStones = new ArrayList<Integer>();
		List<Integer> fourthPlayerStones = new ArrayList<Integer>();
		int temp;
		String temp2;
		int[] playersPoint = new int[4];
		String[] playersName = new String[4];

		okeyStones = createOkeyAllStone(okeyStones);
		okeyBul(okeyStones);
		shuffleStones(okeyStones);
		
		playersStones = distributeStones(okeyStones,playersStones);

		firstPlayerStones = createNewList(playersStones.get(0));
		secondPlayerStones = createNewList(playersStones.get(1));
		thirdPlayerStones = createNewList(playersStones.get(2));
		fourthPlayerStones = createNewList(playersStones.get(3));
		
		int firstPlayerPoint = calculateProbality(firstPlayerStones);
		int secondPlayerPoint= calculateProbality(secondPlayerStones);
		int thirdPlayerPoint= calculateProbality(thirdPlayerStones);
		int fourthPlayerPoint= calculateProbality(fourthPlayerStones);
		
		
		playersPoint[0]=firstPlayerPoint;
		playersPoint[1]=secondPlayerPoint;
		playersPoint[2]=thirdPlayerPoint;
		playersPoint[3]=fourthPlayerPoint;
		
		playersName[0]="1.Oyuncu";
		playersName[1]="2.Oyuncu";
		playersName[2]="3.Oyuncu";
		playersName[3]="4.Oyuncu";
		
		for (int i = 0; i < playersPoint.length; i++) {
		
			for (int j = 1; j < (playersPoint.length-i); j++) {
				
				if(playersPoint[j-1]>playersPoint[j])
				{
					temp = playersPoint[j-1];
					temp2= playersName[j-1];
					playersPoint[j-1]=playersPoint[j];
					playersName[j-1]=playersName[j];
					playersPoint[j]=temp;
					playersName[j]=temp2;
				}
				
			}
		}
		
		for (int i = 0; i < playersName.length; i++) {
			System.out.println(playersName[i]+": " +playersPoint[i]+" Puan");
		}

		System.out.println("--------------------------------------------------------"
						+"\n"+"Kazanma �htimali En Y�ksek Oyuncu: " + playersName[3] +": "+ playersPoint[3]+" Puan");
		
	}
	
	private static int findRandomNumber(int range)
	{
		Random rnd=new Random();
		return rnd.nextInt(range);
	}
	
	private static ArrayList<Integer> createOkeyAllStone(ArrayList<Integer> okeyArray){
		
		for(int i=0;i<53;i++)
		{
			okeyArray.add(i);
			okeyArray.add(i);
		}
		
		return okeyArray;
	}
/**
 * G�sterge se�ildi.
 * Okey ta�� belirlendi ve i�aretlendi.
 * G�sterge dizi d���na ��kar�ld�.
 */
	private static ArrayList<Integer> okeyBul(ArrayList<Integer> okeyArray) {
		
		int indexofGosterge= findRandomNumber((okeyArray.size()/2));

		okeyArray.remove(indexofGosterge*2);

		if(indexofGosterge%13!=12) {
			okeyArray.remove(indexofGosterge*2+1);
			okeyArray.remove(indexofGosterge*2+1);
			okeyArray.set(101, indexofGosterge+1);
			okeyArray.set(102, indexofGosterge+1);
			okeyArray.add(-1);
			okeyArray.add(-1);
		}
		else {
			okeyArray.remove(indexofGosterge-12);
			okeyArray.remove(indexofGosterge-12);
			okeyArray.set(101, indexofGosterge-12);
			okeyArray.set(102, indexofGosterge-12);
			okeyArray.add(-1);
			okeyArray.add(-1);
			
		}
		System.out.println("Gosterge: "+ indexofGosterge +" Okey Ta�lar� "+ okeyArray);
		return okeyArray;
	}
	
	/**
	 * 
	 * Ta�lar Kar��t�r�ld�.
	 * 
	 */
	 private static ArrayList<Integer> shuffleStones(ArrayList<Integer> okeyArray)
	 {	 
		 Collections.shuffle(okeyArray);	 
		 
		 return okeyArray;
	 }
	 
	 /**
	  * 
	  * Ta�lar Da��t�ld�.
	  */
	 private static ArrayList<List<Integer>> distributeStones (ArrayList<Integer> okeyArray, ArrayList<List<Integer>> playersStonesArray){

		 for(int i=0;i<29;i=i+14) {
			 
			 playersStonesArray.add(okeyArray.subList(i,i+14));

		 }
		 playersStonesArray.add(okeyArray.subList(42,57));


		 
		 return playersStonesArray;
	 }
	 
	 /**
	  * 
	  * Ayn� Renkli Perler Bulundu.
	  */
	 private static ArrayList<List<Integer>> findSequencegroup (List<Integer> playerStones)
	 {   
		 ArrayList<List<Integer>> sameColorTrios= new ArrayList<>();

		 Collections.sort(playerStones);
		 System.out.println("Oyuncu Ta�lar� "+playerStones);
		 int t=0;
		 if(playerStones.get(t)==-1)
			 t=t+1;
		 else if(playerStones.get(t)==-1)
			 t=t+1;
		 
		 for(int i=t;i<playerStones.size();i++) {
			 
			 	
				 if(playerStones.get(i)<11)
				 {	
					 sameColorTrios= findTrioGroup(playerStones, i,sameColorTrios);
				    
				 }
				 else if(playerStones.get(i)>12 && playerStones.get(i)<24)
				 {
					 sameColorTrios=findTrioGroup(playerStones, i,sameColorTrios);

				 }
				 else if(playerStones.get(i)>25 && playerStones.get(i)<37)
				 {
					 sameColorTrios=findTrioGroup(playerStones, i,sameColorTrios);

				 }
				 else if(playerStones.get(i)>38 && i<12 && playerStones.get(i)<50)
				 {
					 sameColorTrios=findTrioGroup(playerStones, i,sameColorTrios);

				 }
				
			 }
			 
			 return sameColorTrios;
				 
		 }
	 
	 /**
	  * 
	  * Belirlenen patternlere g�re ayn� renkli 3l� perler belirlendi
	  */
	 private static ArrayList<List<Integer>> findTrioGroup (List<Integer> playerStones,int i,ArrayList<List<Integer>> colorGroup) {
		 
		 if((i<(playerStones.size()-2))&&
		    (playerStones.get(i)+1==playerStones.get(i+1))&&
			(playerStones.get(i+1)+1==playerStones.get(i+2)))
				 {
			 		List<Integer> colorTrioGroup = new ArrayList<Integer>();
			 		colorTrioGroup.add(playerStones.get(i));
			 		colorTrioGroup.add(playerStones.get(i)+1);
			 		colorTrioGroup.add(playerStones.get(i)+2);
			 		colorGroup.add(colorTrioGroup);
			 		
			 		playerStones.remove(i);
			 		playerStones.remove(i);
			 		playerStones.remove(i);
			 		
			 		if(i!=11) 
					findTrioGroup(playerStones,i,colorGroup);
			 		
				 }
		 
		 if((i<(playerStones.size()-3))&&
			(playerStones.get(i)+1==playerStones.get(i+1))&&
			(playerStones.get(i+1)==playerStones.get(i+2))&& 
			(playerStones.get(i+2)==playerStones.get(i+3)))
				 	{
				 		List<Integer> colorTrioGroup = new ArrayList<Integer>();
				 		colorTrioGroup.add(playerStones.get(i));
				 		colorTrioGroup.add(playerStones.get(i)+1);
				 		colorTrioGroup.add(playerStones.get(i)+2);
				 		colorGroup.add(colorTrioGroup);
				 		
				 		playerStones.remove(i);
					    playerStones.remove(i);
					 	playerStones.remove(i+1);
					 	
					 	findTrioGroup(playerStones,i,colorGroup);
					 }
		 return colorGroup;		 
		 
	 }
	 /**
	  * Ayn� say�l� perler belirlendi.
	  * 
	  */
	 private static ArrayList<List<Integer>> findSameNumberedGroup(List<Integer> playerStones,ArrayList<List<Integer>> coloredTrios)
	 {
		 int x=0;
		 if(playerStones.get(x)==-1)
			 x=1;
		 if(playerStones.get(x)==-1)
			 x=2;
		 
		 for(int i=x;i<playerStones.size();i++)
		 {
			 for(int k=i+1;k<playerStones.size();k++)
			 {
				 if(playerStones.get(i)+13==playerStones.get(k))
				 {
					 for(int t=k+1;t<playerStones.size();t++)
					 {
						 if(playerStones.get(k)+13==playerStones.get(t))
						 {
							 List<Integer> coloredTrioGroup = new ArrayList<Integer>();
							 
							 coloredTrioGroup.add(playerStones.get(i));
							 coloredTrioGroup.add(playerStones.get(k));
							 coloredTrioGroup.add(playerStones.get(t));
						     coloredTrios.add(coloredTrioGroup);

					 		 playerStones.remove(i);
							 playerStones.remove(k-1);
							 playerStones.remove(t-2);
							 findSameNumberedGroup(playerStones,coloredTrios);
						 }
						 
					 }
				 }
						 
			 }
			 
		 }
		 return coloredTrios;

	 }
	 /**
	  * 
	  *Kalan ta�lar aras�ndan ayn� renkli ikililer belirlendi.
	  */
	 private static ArrayList<List<Integer>> findDubleSequenceGroup (List<Integer> playerStones)
	 {	
		 ArrayList<List<Integer>> sameColorDubles= new ArrayList<>();
		 
		 int x=0;
		 if(playerStones.get(x)==-1)
			 x=1;
		 if(playerStones.get(x)==-1)
			 x=2;
		 for(int i=x;i<playerStones.size();i++)
		 {
			 if(playerStones.get(i)<12)
			 {
				 sameColorDubles=findSameColorDubleGroup(playerStones,i,sameColorDubles);
			 }
			 else if(playerStones.get(i)<25)
			 {
				 sameColorDubles=findSameColorDubleGroup(playerStones,i,sameColorDubles);
			 }
			 else if(playerStones.get(i)<38)
			 {
				 sameColorDubles= findSameColorDubleGroup(playerStones,i,sameColorDubles);
			 }
			 else if(playerStones.get(i)<51)
			 {
				 sameColorDubles= findSameColorDubleGroup(playerStones,i,sameColorDubles);
			 }

		 }
		 
		 return sameColorDubles;
	 }
	 
	 /**
	  * 
	  * �kili gruplar belirlendi.
	  */
	 private static ArrayList<List<Integer>> findSameColorDubleGroup (List<Integer> playerStones,int i,ArrayList<List<Integer>> dubleSeqGroup) {
		 
		 if(i<playerStones.size()-1) {
			 if(playerStones.get(i)+1==playerStones.get(i+1))
				 {
				 	List<Integer> dubleGroup = new ArrayList<Integer>();
				 	dubleGroup.add(playerStones.get(i));
				 	dubleGroup.add(playerStones.get(i+1));
				 	dubleSeqGroup.add(dubleGroup);
				 	
				 	playerStones.remove(i);
			 		playerStones.remove(i);
			 		
			 		if(dubleGroup.get(1)!=12&& dubleGroup.get(1)!=25&&dubleGroup.get(1)!=38 && playerStones.size()>2)
			 			findSameColorDubleGroup(playerStones, i, dubleSeqGroup);
				 }
		 }
	 return dubleSeqGroup;
		 
	 }
	 
	 /**
	  * 
	  * Ayn� say�daki ikililer belirlendi.
	  */
	 private static ArrayList<List<Integer>> findDubleGroup (List<Integer> playerStones,ArrayList<List<Integer>> sameNumberDublesList)
	 {
		 int x=0;
		 if(playerStones.get(x)==-1)
			 x=1;
		 if(playerStones.get(x)==-1)
			 x=2;
		 for(int i=x;i<playerStones.size();i++)
		 {
			 for(int k=i+1;k<playerStones.size();k++)
			 {
				 if(playerStones.get(i)+13==playerStones.get(k))
				 {
					 List<Integer> sameNumberDubleGroup = new ArrayList<Integer>();
					 
					 sameNumberDubleGroup.add(playerStones.get(i));
					 sameNumberDubleGroup.add(playerStones.get(k));
					 sameNumberDublesList.add(sameNumberDubleGroup);

			 		 playerStones.remove(i);
					 playerStones.remove(k-1);
					 findDubleGroup(playerStones,sameNumberDublesList);
				 }
			 }
		 }
		 
		 return sameNumberDublesList;
		 
	 }
	 /**
	  * 
	  * Her bir Oyuncu i�in elinde olu�an 3l� ve 2li perler belirlendikten sonra 
	  * bu perlere, okey ta� sa�y�s�na ve kalan ta�lar� baz alarak bir puan hesapland�.
	  * 
	  */
	 private static int calculateProbality(List<Integer> playerStones)
	 {
		 ArrayList<List<Integer>> sameColorTrios= new ArrayList<>();
		 ArrayList<List<Integer>> sameColorDubles= new ArrayList<>();
		 ArrayList<List<Integer>> sameNumberedTrios= new ArrayList<>();
		 ArrayList<List<Integer>> sameNumberedDubles= new ArrayList<>();
		 int okeyCount=0;
		 int okeyPoint=3;
		 int sameColorTriosPoint=10;
		 int sameNumberTriosPoint=8;
		 int sameColorDublesPoint=6;
		 int sameNumberDublesPoint=4;
		 int remainingStonesPoint=-2;
		 int point;
		 
		 sameColorTrios = findSequencegroup(playerStones);
		 sameNumberedTrios= findSameNumberedGroup(playerStones, sameNumberedTrios);
		 sameColorDubles= findDubleSequenceGroup(playerStones);
		 sameNumberedDubles=findDubleGroup(playerStones,sameNumberedDubles);
		 
			
			while (playerStones.get(0)==-1)
			{
				okeyCount=okeyCount+1;
				if(sameColorDubles.isEmpty()==false)
				{
					sameColorDubles.get(0).add(playerStones.get(0));
					sameColorTrios.add(sameColorDubles.get(0));
					sameColorDubles.remove(0);
					playerStones.remove(0);
				}
				else if(sameNumberedDubles.isEmpty()==false)
				{
					sameNumberedDubles.get(0).add(playerStones.get(0));
					sameNumberedTrios.add(sameNumberedDubles.get(0));
					sameNumberedDubles.remove(0);
					playerStones.remove(0);
				}
				
			}
			
			
			System.out.println("Ayn� Renk Perler: "+sameColorTrios);
			System.out.println("Ayn� Say� Perler: "+sameNumberedTrios);
			System.out.println("Ayn� Renk �kililer: "+sameColorDubles);
			System.out.println("Ayn� Say� �kililer: "+sameNumberedDubles);
			System.out.println("Kalan Taslar" + playerStones);
			System.out.println("*************************************************************************");

			point=sameColorTrios.size()*sameColorTriosPoint+sameNumberedTrios.size()*sameNumberTriosPoint+
				  sameColorDubles.size()*sameColorDublesPoint+sameNumberDublesPoint*sameNumberDublesPoint+
				  okeyCount*okeyPoint+
				  playerStones.size()*remainingStonesPoint;
		 
		 return point;
	 }
	 
	 public static List<Integer> createNewList(List<Integer> list){
			List<Integer> rtnList = new ArrayList<Integer>();
			
			for(Integer item :  list) {
				rtnList.add(item);
			}
			
			return rtnList;
		}
	 
}

